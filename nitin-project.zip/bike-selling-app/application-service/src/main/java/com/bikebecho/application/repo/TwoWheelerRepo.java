package com.bikebecho.application.repo;

import com.bikebecho.application.models.TwoWheeler;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TwoWheelerRepo extends JpaRepository<TwoWheeler, Long> {
}
