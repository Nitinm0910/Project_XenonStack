package com.bikebecho.application.service;

import com.bikebecho.application.models.User;
import com.bikebecho.application.repo.UserRepo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService{

    @Resource
    private UserRepo userRepo;

    @Override
    public void saveData(User user) {
        this.userRepo.save(user);
    }

    @Override
    public User getUserById(Long id) {
        return this.userRepo.findById(id).isPresent()?this.userRepo.findById(id).get():null;
    }
}
