package com.bikebecho.application.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TwoWheeler {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="ID")
    private Long id;

    @Column(name="REGISTRATION_NO")
    private String registrationNumber;

    @Column(name="AGE")
    private Integer age;

    @Column(name="MODEL")
    private String model;

    @Column(name="ENGINE_CAPACITY")
    private String engineCapacity;

    @Column(name="IS_GEARLESS")
    private Boolean isGearless;

    @Column(name="NO_OF_GEARS")
    private Integer noOfGears;
}
