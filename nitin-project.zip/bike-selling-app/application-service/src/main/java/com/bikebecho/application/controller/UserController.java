package com.bikebecho.application.controller;

import com.bikebecho.application.models.User;
import com.bikebecho.application.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/save_user")
    public void saveUserData(@RequestBody User user){
        this.userService.saveData(user);
    }

    @GetMapping("/get_user/{id}")
    public User getUserData(@PathVariable("id") Long id){
        return this.userService.getUserById(id);
    }
}
