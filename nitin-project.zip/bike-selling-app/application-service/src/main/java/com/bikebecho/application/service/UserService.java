package com.bikebecho.application.service;

import com.bikebecho.application.models.User;
import org.springframework.stereotype.Service;


public interface UserService {

   void saveData(User user);
   User getUserById(Long id);
}
