package com.bikebecho.application.repo;

import org.springframework.stereotype.Repository;

@Repository
public abstract class UserRepoImpl implements UserRepo{

}
