package com.bikebecho.application.service;

import com.bikebecho.application.models.TwoWheeler;
import com.bikebecho.application.repo.TwoWheelerRepo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class TwoWheelerServiceimpl implements TwoWheelerService {

    @Resource
    TwoWheelerRepo twoWheelerRepo;
    @Override
    public TwoWheeler getTwoWheelerById(Long id) {
        return this.twoWheelerRepo.findById(id).isPresent() ? this.twoWheelerRepo.findById(id).get() : null;
    }

    public List<TwoWheeler> getAllTwoWheelers(){
        return this.twoWheelerRepo.findAll();
    }
}
