package com.bikebecho.application.service;

import com.bikebecho.application.models.TwoWheeler;
import com.bikebecho.application.repo.TwoWheelerRepo;

public interface TwoWheelerService {

    TwoWheeler getTwoWheelerById(Long id);
}
