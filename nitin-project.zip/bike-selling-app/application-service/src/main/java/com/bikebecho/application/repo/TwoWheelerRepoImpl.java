package com.bikebecho.application.repo;

import com.bikebecho.application.models.TwoWheeler;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public abstract class TwoWheelerRepoImpl implements TwoWheelerRepo {
}
